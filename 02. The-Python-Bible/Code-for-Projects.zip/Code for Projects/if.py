num1 = 500
num2 = 500

if num1 > num2:
    print("num1 is bigger than num2")
elif num2 > num1:
    print("num2 is bigger than num1")
else:
    print("Both numbers are equal")

if condition:
    code
elif condition2:
    code2
elif condition3:
    code3
else:
    code4
