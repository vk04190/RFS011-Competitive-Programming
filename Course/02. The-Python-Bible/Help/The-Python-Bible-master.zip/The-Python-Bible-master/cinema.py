#! /usr/bin/python3.6

films = {
    "Finding Dory": [3, 5],
    "Bourne": [18, 5],
    "Tarzan": [15, 5],
    "GhostBusters": [12, 5]

}

while True:
    choice = input("What is your choice? ").strip().capitalize()
    print(choice)
