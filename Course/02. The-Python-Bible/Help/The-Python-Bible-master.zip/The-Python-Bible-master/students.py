#! /usr/bin/python3.6

# A dictionary named students. it includes the students ID, Age, & Grade.
students = {
    "Alice": {"id": "ID0001", "Age": 26, "Grade": "A"},
    "Bob": {"id": "ID0002", "Age": 23, "Grade": "B"},
    "Clair": {"id": "ID0003", "Age": 21, "Grade": "C"},
    "Dan": {"id": "ID0004", "Age": 17, "Grade": "E"},
    "Emma": {"id": "ID0005", "Age": 20, "Grade": "A"},
    "Tom": {"id": "ID0006", "Age": 29, "Grade": "B"},
    "Tom": {"id": "ID0007", "Age": 25, "Grade": "D"},
    "Sam": {"id": "ID0008", "Age": 20, "Grade": "A"},
    "Travis": {"id": "ID0009", "Age": 21, "Grade": "A"}
}
#print(students)
#print(students["Clair"])
#print(students["Clair"][0])
#print(students["Dan"][1:])
#print(students["Sam"])
#print(students["Dan"]["Age"])
#print(students["Emma"]["Age"], students["Emma"]["Grade"])
