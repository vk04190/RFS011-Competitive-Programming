#! /usr/bin/python3.6

numbers = list(range(3))
letters = list("abc")

one, two, three = numbers
print(one)
print(two)
print(three)

#num_letter = numbers + letters

#print(num_letter[0])
#print(num_letter[1])
#print(num_letter[2])

#print(num_letter)
