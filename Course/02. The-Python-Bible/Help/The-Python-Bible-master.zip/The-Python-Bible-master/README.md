# The-Python-Bible
My projects from the Udemy course called The Python Bible.
