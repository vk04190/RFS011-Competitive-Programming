#! /usr/bin/python3.6

a = 250

def f1():
    b = a + 10
    print(b)

def f2():
    a = 50
    print(a)

f1()
f2()
print(a)
